#include <Arduino.h>
#include <SPI.h>

#include"indicators.h"
#include "Lora.h"
#include "IMU.h"
#include "SDLog.h"
#include "gps.h"
#include "Altitude.h"
#include "RocketState.h"
#include "Piro.h"
#include "BMP.h"

#define SCK         12
#define MISO        13
#define MOSI        15

// =======================
// Setup
// =======================
void setup() {
  SPI.begin(SCK, MISO, MOSI, -1);
  InitPiro();
  InitLED();
  InitIMU();
  InitLora ();
  InitSD();
  InitBMP();
}


void loop() {
 
  UpdateState(); // update the rcokets state and run main flight claculations to detect apogee, launch, and major flight events.
  SendData();//lora send
  updatePiro(); // Update the piro channels
 logDataAtRate(1000, "Rocket State: " + String(GetState())); // Log rocket state every second
}


  


