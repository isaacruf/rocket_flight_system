#ifndef SDLOG_H
#define SDLOG_H

void InitSD();
void logDataAtRate(unsigned long intervalMs, const String& data);
void CreateLogFile();
#endif