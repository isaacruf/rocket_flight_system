#include <SD.h>
#include <SPI.h>
#include "SDLog.h"
#include <Arduino.h>

#define SD_CS 22

File logFile;
String logFileName;
unsigned long lastLogTime = 0;
bool logFileCreated = false;

String getNextFileName() {
    int flightNum = 1;
    String fname;
    do {
        fname = "flight" + String(flightNum) + ".csv";
        flightNum++;
    } while (SD.exists(fname));
    return fname;
}

void InitSD() {
    if (!SD.begin(SD_CS, SPI)) {
        Serial.println("SD init failed!");
        while (true);
    }
    Serial.println("SD card ready.");
    delay(200);
    logFileCreated = false; // Reset flag on init
}

void createLogFile() {
    if (logFileCreated) return; // Only create once per flight
    logFileName = getNextFileName();
    logFile = SD.open(logFileName, FILE_WRITE);
    if (logFile) {
        logFile.println("Time,AccelX,AccelY,AccelZ,..."); // Example header
        logFile.close();
        Serial.print("Logging to: ");
        Serial.println(logFileName);
        logFileCreated = true;
    } else {
        Serial.println("Failed to create log file!");
    }
}

void logDataAtRate(unsigned long intervalMs, const String& data) {
    if (!logFileCreated) return; // Only log if file is created (armed)
    unsigned long now = millis();
    if (now - lastLogTime >= intervalMs) {
        logFile = SD.open(logFileName, FILE_WRITE);
        if (logFile) {
            logFile.println(data);
            logFile.close();
        }
        lastLogTime = now;
    }
}