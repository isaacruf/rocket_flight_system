#ifndef GPS_H
#define GPS_H

#include <TinyGPS++.h>
#include <HardwareSerial.h>

class GPS {
public:
    GPS(HardwareSerial& serial);
    void begin();
    bool update();
    float getLatitude();
    float getLongitude();
    float getAltitude();
    float getSpeed();

private:
    HardwareSerial& _serial;
    TinyGPSPlus _gps;
};

#endif