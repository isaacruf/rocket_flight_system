#include "BMP.h"
#include <Wire.h>
#include <SparkFun_BMP581_Arduino_Library.h>

BMP581 bmp;

void InitBMP() {
    Wire.begin();
    if (bmp.beginI2C() != BMP5_OK) {
        Serial.println("Could not find a valid BMP581 sensor, check wiring!");
        while (1);
    }
    Serial.println("BMP581 sensor initialized.");
}

float GetAltitude() {
    float pressure, temperature;
    if (bmp.getSensorData(&pressure, &temperature) == BMP5_OK) {
        // Standard sea level pressure = 1013.25 hPa
        return 44330.0 * (1.0 - pow(pressure / 1013.25, 0.1903));
    } else {
        Serial.println("BMP581 read error!");
        return -1;
    }
}