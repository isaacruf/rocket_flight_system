#ifndef BMP_H
#define BMP_H
#include <Adafruit_BMP581.h>
#include <Arduino.h>
#include <Wire.h>
// Initializes the BMP sensor
void InitBMP();
// Returns the current altitude in meters
float GetBMPAltitude();

#endif
