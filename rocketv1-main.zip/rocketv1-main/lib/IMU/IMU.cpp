#include "IMU.h"
#include <Adafruit_Sensor.h>
#include <Adafruit_LSM9DS1.h>

#define SCK         12
#define MISO        13
#define MOSI        15
#define IMU_CS_AG   17
#define IMU_CS_M    16

Adafruit_LSM9DS1 lsm = Adafruit_LSM9DS1(SCK, MISO, MOSI, IMU_CS_AG, IMU_CS_M);

void InitIMU() {
    if (!lsm.begin()) {
        Serial.println("LSM9DS1 init failed!");
        while (1);
    }
    Serial.println("IMU init success");
    delay(200);

    lsm.setupAccel(lsm.LSM9DS1_ACCELRANGE_16G);
    lsm.setupMag(lsm.LSM9DS1_MAGGAIN_4GAUSS);
    lsm.setupGyro(lsm.LSM9DS1_GYROSCALE_2000DPS);
}

AccelData getRawAccelData() {
    sensors_event_t accel, mag, gyro, temp;
    lsm.getEvent(&accel, &mag, &gyro, &temp);
    return {accel.acceleration.x, accel.acceleration.y, accel.acceleration.z};
}

GyroData getRawGyroData() {
    sensors_event_t accel, mag, gyro, temp;
    lsm.getEvent(&accel, &mag, &gyro, &temp);
    return {gyro.gyro.x, gyro.gyro.y, gyro.gyro.z};
}

MagData getRawMagData() {
    sensors_event_t accel, mag, gyro, temp;
    lsm.getEvent(&accel, &mag, &gyro, &temp);
    return {mag.magnetic.x, mag.magnetic.y, mag.magnetic.z};
}

TempData getRawTempData() {
    sensors_event_t accel, mag, gyro, temp;
    lsm.getEvent(&accel, &mag, &gyro, &temp);
    return {temp.temperature};
}