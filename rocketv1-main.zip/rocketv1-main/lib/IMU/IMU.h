#ifndef IMU_H
#define IMU_H
#include <Adafruit_Sensor.h>
#include <Adafruit_LSM9DS1.h>

void InitIMU();

struct AccelData {
    float x, y, z;
};

struct GyroData {
    float x, y, z;
};

struct MagData {
    float x, y, z;
};

struct TempData {
    float temperature;
};

AccelData getRawAccelData();
GyroData getRawGyroData();
MagData getRawMagData();
TempData getRawTempData();

#endif