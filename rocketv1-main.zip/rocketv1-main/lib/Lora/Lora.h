#ifndef LORA_H
#define LORA_H

// Initializes the LoRa module
void InitLora();

// Sends data over LoRa
void SendData();
void ReceiveData();
void ReceiveFlightCommands();


#endif