#include <Arduino.h>
#include "gps.h"//tog get gps location
#include <RadioLib.h>
// =======================
// Telemetry Config
// =======================
// LoRa module: Pass the custom SPIClass object (SPI_LoRa_SD)
SX1262 lora = SX1262(LORA_CS, LORA_BUSY, LORA_RST, LORA_DIO1);
#define LORA_RST         14
#define LORA_BUSY        26
#define LORA_DIO1        27 
#define LORA_CS          5

unsigned long lastSendTimeAscent = 0;
unsigned long lastSendTimeDescent = 0;
unsigned long lastSendTimeLanded = 0;

const unsigned long SendIntervalAscent = 10;
const unsigned long SendIntervalDescent = 40;
const unsigned long SendIntervalLanded = 200;
// ======================
// Telemetry Packet Structs
// =======================
struct AscentPacket {
  uint8_t State;
  float altitude;
  float Zvelocity;
};

struct DescentPacket {
  float altitude;
  float latitude;
  float longitude;
};

struct Landededpacket {
  float altitude;
  float latitude;
  float longitude;
};
void InitLora();{
    // Initialize LoRa
  if (lora.begin() != RADIOLIB_ERR_NONE) {
    Serial.println("LoRa init failed!");
    while (true); // Halt on failure
  }
  Serial.println("LoRa initialized successfully.");
  delay(200);
}
void SendData() {
  unsigned long now = millis();

  // --- ASCENT PHASE ---
  if (CurrentState == Launched || CurrentState == Ignition || CurrentState == Apogee) {
    if (now - lastSendTimeAscent < SendIntervalAscent) return;

    AscentPacket pkt;
    pkt.State = static_cast<uint8_t>(CurrentState);
    pkt.altitude = 1234.5;      // Replace with real data
    pkt.Zvelocity = 67.8;

    lora.transmit((uint8_t*)&pkt, sizeof(pkt));
    Serial.println(F("[TX] Ascent Packet"));

    lastSendTimeAscent = now;
  }

  // --- DESCENT PHASE ---
  else if (CurrentState == Drogue || CurrentState == Main ) {
    if (now - lastSendTimeDescent < SendIntervalDescent) return;

    DescentPacket pkt;
    pkt.altitude = 345.6;
    pkt.latitude = 37.1234;
    pkt.longitude = -122.4567;

    lora.transmit((uint8_t*)&pkt, sizeof(pkt));
    Serial.println(F("[TX] Descent Packet"));

    lastSendTimeDescent = now;
  }

  // --- LANDED PHASE ---
  else if (CurrentState == Landed) {
    if (now - lastSendTimeLanded < SendIntervalLanded) return;

    DescentPacket pkt;
    pkt.altitude = 0.0;         // Or final alt reading
    pkt.latitude = 37.1234;
    pkt.longitude = -122.4567;

    lora.transmit((uint8_t*)&pkt, sizeof(pkt));
    Serial.println(F("[TX] Landed Packet"));

    lastSendTimeLanded = now;
  }
}