#ifndef ROCKETSTATE_H
#define ROCKETSTAE_H
#include "indicators.h"
#include "Piro.h"
#include "Calcavonics.h"
#include <Arduino.h>
// =======================
// State Machine
// =======================
enum RocketState {
  Safe,
  Test,
  Armed,
  Launched,
  Ignition,
  Flight,
  Apogee,
  Drogue,
  Main,
  Landed
};
RocketState CurrentState = Safe;
RocketState GetState();
void UpdateState();
#endif