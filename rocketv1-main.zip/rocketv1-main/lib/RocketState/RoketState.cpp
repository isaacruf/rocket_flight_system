#include "RocketState.h"
#include "indicators.h"
#include "Piro.h"
#include "Altitude.h"
#include <Arduino.h>


void UpdateState(){
    switch (CurrentState) {
        //safe mode default state
        case Safe:
            FlashLED(0,255,0,200,200);
        String cmd = GetFlightCommand();
        if (cmd == "test") {
        CurrentState = Test;
        }
       if (cmd == "armed") {
        CurrentState = Armed;
        }
        break;
        //test  mode
        case Test:
        if (GetFlightCommand() == "flight") {
            CurrentState = Safe;
        }

            FlashLED(0,255,0,200,200);
            break;
            //armed mode
            case Armed:
           if (GetFlightCommand() == "test") {
                CurrentState = Test;
            }
           if (GetFlightCommand() == "safe") {
                CurrentState = Safe;
            }
            if (GetFlightCommand() == "launch") {
                CurrentState = Launched;
            }
            //indicators
            FlashLED(255,0,0,200,200);
            BeepBuzzer(100,1200);
            break;
        case Launched:
            FlashLED(255,0,0,100,100);
            BeepBuzzer(100,1200);
            if (GetAltitude() > 10) {
                CurrentState = Ignition;
            }
            break;
        case Ignition:
            FlashLED(0,0,0,200,200);
            BeepBuzzer(100,1200);

            if (ignitePiro(1)) {
                CurrentState = flight;
            }
            break;
        case flight:
            if (getvolivity() < 0) {
                if (!negativeVelocityTimerActive) {
                    negativeVelocityStart = millis();
                    negativeVelocityTimerActive = true;
                } else if (millis() - negativeVelocityStart >= 1000) {
                    // Velocity has been negative for at least 1 second
                    CurrentState = Apogee;
                    negativeVelocityTimerActive = false; // reset for next use
                }
            } else {
                // Velocity is not negative, reset timer
                negativeVelocityTimerActive = false;
            }
            break;
        case Apogee:
            if (ignitePiro(2)) {
               CurrentState = Drogue;
           }
        break;
        case Drogue:
          if (getAltitude() < 100) {
            if (ignitePiro(3)) {
               CurrentState = Main;
           }
            break;
        case Main:
        if (getAltitude() < 10) {
            CurrentState = Landed;
        }
            break;
        case Landed:
            BeepBuzzer(2000,1200);
            break;
    }
}

RocketState GetState(){
return CurrentState;
 }