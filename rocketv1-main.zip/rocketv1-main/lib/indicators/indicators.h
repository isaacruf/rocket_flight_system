#ifndef INDICATORS_H
#define INDICATORS_H
void FlashLED(int R, int G, int B, int LEDDelay, int LEDOnTime);
void BeepBuzzer(int BuzzerPulseRate, int BuzzerHz);
void InitLED();
#endif