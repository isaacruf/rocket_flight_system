//used to flash leds and sound buzzer and idicate all rocket states 
#include <Adafruit_NeoPixel.h>
#include <Arduino.h>
#define BUZZER_PIN       8
#define LED_PIN          39
 #include"indicators.h"

Adafruit_NeoPixel pixels(1, LED_PIN, NEO_GRB + NEO_KHZ800);

void InitLED(){
  pixels.begin();
  Serial.begin(115200);
  delay(1000);

}
void FlashLED(int R, int G, int B, int LEDDelay, int LEDOnTime)//r,g,b,ledofftime,ledontime
 {
  static bool ledOn = false;
  static unsigned long LEDLastToggle = 0;
  unsigned long currentMillis = millis();

  if (!ledOn && (currentMillis - LEDLastToggle >= LEDDelay)) {
    pixels.setPixelColor(0, pixels.Color(R, G, B));
    pixels.show();
    ledOn = true;
    LEDLastToggle = currentMillis;
  } else if (ledOn && (currentMillis - LEDLastToggle >= LEDOnTime)) {
    pixels.clear();
    pixels.show();
    ledOn = false;
    LEDLastToggle = currentMillis;
  }
}

void BeepBuzzer(int BuzzerPulseRate, int BuzzerHz) {

  static unsigned long lastToggleTime = 0;
  static bool buzzerOn = false;

  unsigned long currentMillisBuzzer = millis();

  if (currentMillisBuzzer - lastToggleTime >= BuzzerPulseRate) {
    if (buzzerOn) {
      noTone(BUZZER_PIN);
      buzzerOn = false;
    } else {
      tone(BUZZER_PIN, BuzzerHz);
      buzzerOn = true;
    }
    lastToggleTime = currentMillisBuzzer;
  }

}