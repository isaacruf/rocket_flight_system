#ifndef Piro_H
#define Piro_H
// Ignites the specified pyro channel (e.g., channel 1, 2, etc.)
bool ignitePiro(int channel);
void InitPiro();
void updatePiro();
#endif