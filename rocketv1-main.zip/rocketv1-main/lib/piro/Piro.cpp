#include "Piro.h"
#include <Arduino.h>

const int pyroPins[] = {5, 6, 7, 8};
const int numChannels = sizeof(pyroPins) / sizeof(pyroPins[0]);
const unsigned long IGNITE_DURATION = 1000; // milliseconds

struct PyroChannelState {
    bool ignited;
    unsigned long startTime;
};

PyroChannelState pyroStates[sizeof(pyroPins) / sizeof(pyroPins[0])] = {0};

void InitPiro() {
    for (int i = 0; i < numChannels; i++) {
        pinMode(pyroPins[i], OUTPUT);
        digitalWrite(pyroPins[i], LOW);
        pyroStates[i].ignited = false;
        pyroStates[i].startTime = 0;
    }
}

bool ignitePiro(int channel) {
    if (channel < 1 || channel > numChannels) return;
    int idx = channel - 1;
    digitalWrite(pyroPins[idx], HIGH);
    pyroStates[idx].ignited = true;
    pyroStates[idx].startTime = millis();
    return true;
}

// Call this function repeatedly in your main loop
void updatePiro() {
    unsigned long now = millis();
    for (int i = 0; i < numChannels; i++) {
        if (pyroStates[i].ignited && (now - pyroStates[i].startTime >= IGNITE_DURATION)) {
            digitalWrite(pyroPins[i], LOW);
            pyroStates[i].ignited = false;
        }
    }
}